﻿namespace Ganesh_Cycle_Agency
{
    partial class frm_Search_Or_Update_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Search_Or_Update_Employee));
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.dtp_Joining_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Aadhaar_Card_No = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No_2 = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No_1 = new System.Windows.Forms.TextBox();
            this.tb_Employee_Name = new System.Windows.Forms.TextBox();
            this.lbl_Aadhaar_Card_No = new System.Windows.Forms.Label();
            this.lbl_Mobile_No_2 = new System.Windows.Forms.Label();
            this.lbl_Mobile_No_1 = new System.Windows.Forms.Label();
            this.lbl_Registration_N0 = new System.Windows.Forms.Label();
            this.lbl_Joining_Date = new System.Windows.Forms.Label();
            this.lbl_Employee_Name = new System.Windows.Forms.Label();
            this.pnl_Search_Or_Update_Employee = new System.Windows.Forms.Panel();
            this.btn_Update = new System.Windows.Forms.Button();
            this.tb_Employee_ID = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.lbl_Employee_ID = new System.Windows.Forms.Label();
            this.lbl_Search_Or_Update_Employee = new System.Windows.Forms.Label();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.tb_Note = new System.Windows.Forms.TextBox();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.tb_Designation = new System.Windows.Forms.TextBox();
            this.lbl_Designation = new System.Windows.Forms.Label();
            this.tb_Salary = new System.Windows.Forms.TextBox();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.pnl_Search_Or_Update_Employee.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.White;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(1411, 18);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(218, 55);
            this.btn_Refresh.TabIndex = 121;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // dtp_Joining_Date
            // 
            this.dtp_Joining_Date.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtp_Joining_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Joining_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Joining_Date.Location = new System.Drawing.Point(1308, 351);
            this.dtp_Joining_Date.Name = "dtp_Joining_Date";
            this.dtp_Joining_Date.Size = new System.Drawing.Size(346, 34);
            this.dtp_Joining_Date.TabIndex = 120;
            // 
            // tb_Aadhaar_Card_No
            // 
            this.tb_Aadhaar_Card_No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Aadhaar_Card_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhaar_Card_No.Location = new System.Drawing.Point(1308, 471);
            this.tb_Aadhaar_Card_No.Name = "tb_Aadhaar_Card_No";
            this.tb_Aadhaar_Card_No.Size = new System.Drawing.Size(346, 41);
            this.tb_Aadhaar_Card_No.TabIndex = 112;
            // 
            // tb_Mobile_No_2
            // 
            this.tb_Mobile_No_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_2.Location = new System.Drawing.Point(473, 620);
            this.tb_Mobile_No_2.Name = "tb_Mobile_No_2";
            this.tb_Mobile_No_2.Size = new System.Drawing.Size(342, 42);
            this.tb_Mobile_No_2.TabIndex = 118;
            // 
            // tb_Mobile_No_1
            // 
            this.tb_Mobile_No_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_1.Location = new System.Drawing.Point(473, 481);
            this.tb_Mobile_No_1.Name = "tb_Mobile_No_1";
            this.tb_Mobile_No_1.Size = new System.Drawing.Size(342, 42);
            this.tb_Mobile_No_1.TabIndex = 116;
            // 
            // tb_Employee_Name
            // 
            this.tb_Employee_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Employee_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employee_Name.Location = new System.Drawing.Point(473, 351);
            this.tb_Employee_Name.Name = "tb_Employee_Name";
            this.tb_Employee_Name.Size = new System.Drawing.Size(342, 42);
            this.tb_Employee_Name.TabIndex = 115;
            // 
            // lbl_Aadhaar_Card_No
            // 
            this.lbl_Aadhaar_Card_No.AutoSize = true;
            this.lbl_Aadhaar_Card_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aadhaar_Card_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhaar_Card_No.Location = new System.Drawing.Point(1038, 481);
            this.lbl_Aadhaar_Card_No.Name = "lbl_Aadhaar_Card_No";
            this.lbl_Aadhaar_Card_No.Size = new System.Drawing.Size(226, 34);
            this.lbl_Aadhaar_Card_No.TabIndex = 111;
            this.lbl_Aadhaar_Card_No.Text = "Aadhaar Card No";
            // 
            // lbl_Mobile_No_2
            // 
            this.lbl_Mobile_No_2.AutoSize = true;
            this.lbl_Mobile_No_2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_2.Location = new System.Drawing.Point(187, 622);
            this.lbl_Mobile_No_2.Name = "lbl_Mobile_No_2";
            this.lbl_Mobile_No_2.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_2.TabIndex = 108;
            this.lbl_Mobile_No_2.Text = "Mobile No 2";
            // 
            // lbl_Mobile_No_1
            // 
            this.lbl_Mobile_No_1.AutoSize = true;
            this.lbl_Mobile_No_1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_1.Location = new System.Drawing.Point(187, 483);
            this.lbl_Mobile_No_1.Name = "lbl_Mobile_No_1";
            this.lbl_Mobile_No_1.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_1.TabIndex = 109;
            this.lbl_Mobile_No_1.Text = "Mobile No 1";
            // 
            // lbl_Registration_N0
            // 
            this.lbl_Registration_N0.AutoSize = true;
            this.lbl_Registration_N0.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Registration_N0.Location = new System.Drawing.Point(397, 38);
            this.lbl_Registration_N0.Name = "lbl_Registration_N0";
            this.lbl_Registration_N0.Size = new System.Drawing.Size(0, 34);
            this.lbl_Registration_N0.TabIndex = 74;
            // 
            // lbl_Joining_Date
            // 
            this.lbl_Joining_Date.AutoSize = true;
            this.lbl_Joining_Date.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Joining_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Joining_Date.Location = new System.Drawing.Point(1038, 351);
            this.lbl_Joining_Date.Name = "lbl_Joining_Date";
            this.lbl_Joining_Date.Size = new System.Drawing.Size(164, 34);
            this.lbl_Joining_Date.TabIndex = 105;
            this.lbl_Joining_Date.Text = "Joining Date";
            // 
            // lbl_Employee_Name
            // 
            this.lbl_Employee_Name.AutoSize = true;
            this.lbl_Employee_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Employee_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_Name.Location = new System.Drawing.Point(187, 359);
            this.lbl_Employee_Name.Name = "lbl_Employee_Name";
            this.lbl_Employee_Name.Size = new System.Drawing.Size(212, 34);
            this.lbl_Employee_Name.TabIndex = 106;
            this.lbl_Employee_Name.Text = "Employee Name";
            // 
            // pnl_Search_Or_Update_Employee
            // 
            this.pnl_Search_Or_Update_Employee.BackColor = System.Drawing.Color.LightGray;
            this.pnl_Search_Or_Update_Employee.Controls.Add(this.btn_Refresh);
            this.pnl_Search_Or_Update_Employee.Controls.Add(this.btn_Update);
            this.pnl_Search_Or_Update_Employee.Controls.Add(this.tb_Employee_ID);
            this.pnl_Search_Or_Update_Employee.Controls.Add(this.btn_Search);
            this.pnl_Search_Or_Update_Employee.Controls.Add(this.lbl_Employee_ID);
            this.pnl_Search_Or_Update_Employee.Controls.Add(this.lbl_Registration_N0);
            this.pnl_Search_Or_Update_Employee.Location = new System.Drawing.Point(100, 185);
            this.pnl_Search_Or_Update_Employee.Name = "pnl_Search_Or_Update_Employee";
            this.pnl_Search_Or_Update_Employee.Size = new System.Drawing.Size(1703, 93);
            this.pnl_Search_Or_Update_Employee.TabIndex = 102;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Update.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.Location = new System.Drawing.Point(1090, 20);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(181, 53);
            this.btn_Update.TabIndex = 70;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // tb_Employee_ID
            // 
            this.tb_Employee_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Employee_ID.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employee_ID.Location = new System.Drawing.Point(320, 27);
            this.tb_Employee_ID.Name = "tb_Employee_ID";
            this.tb_Employee_ID.Size = new System.Drawing.Size(342, 45);
            this.tb_Employee_ID.TabIndex = 76;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(779, 20);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(181, 53);
            this.btn_Search.TabIndex = 69;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // lbl_Employee_ID
            // 
            this.lbl_Employee_ID.AutoSize = true;
            this.lbl_Employee_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_ID.Location = new System.Drawing.Point(73, 38);
            this.lbl_Employee_ID.Name = "lbl_Employee_ID";
            this.lbl_Employee_ID.Size = new System.Drawing.Size(172, 34);
            this.lbl_Employee_ID.TabIndex = 75;
            this.lbl_Employee_ID.Text = "Employee ID";
            // 
            // lbl_Search_Or_Update_Employee
            // 
            this.lbl_Search_Or_Update_Employee.AutoSize = true;
            this.lbl_Search_Or_Update_Employee.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Search_Or_Update_Employee.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Search_Or_Update_Employee.Location = new System.Drawing.Point(559, 75);
            this.lbl_Search_Or_Update_Employee.Name = "lbl_Search_Or_Update_Employee";
            this.lbl_Search_Or_Update_Employee.Size = new System.Drawing.Size(805, 77);
            this.lbl_Search_Or_Update_Employee.TabIndex = 101;
            this.lbl_Search_Or_Update_Employee.Text = "Search Or Update Employee";
            // 
            // btn_Logout
            // 
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.ForeColor = System.Drawing.Color.Black;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.Location = new System.Drawing.Point(1775, 22);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(68, 59);
            this.btn_Logout.TabIndex = 139;
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Image = ((System.Drawing.Image)(resources.GetObject("btn_Back.Image")));
            this.btn_Back.Location = new System.Drawing.Point(56, 35);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(63, 59);
            this.btn_Back.TabIndex = 138;
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // tb_Note
            // 
            this.tb_Note.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Note.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Note.Location = new System.Drawing.Point(1308, 732);
            this.tb_Note.MaxLength = 50;
            this.tb_Note.Multiline = true;
            this.tb_Note.Name = "tb_Note";
            this.tb_Note.Size = new System.Drawing.Size(346, 83);
            this.tb_Note.TabIndex = 144;
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Note.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.Location = new System.Drawing.Point(1053, 748);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(73, 34);
            this.lbl_Note.TabIndex = 148;
            this.lbl_Note.Text = "Note";
            // 
            // tb_Designation
            // 
            this.tb_Designation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Designation.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Designation.Location = new System.Drawing.Point(468, 766);
            this.tb_Designation.Name = "tb_Designation";
            this.tb_Designation.Size = new System.Drawing.Size(346, 42);
            this.tb_Designation.TabIndex = 140;
            // 
            // lbl_Designation
            // 
            this.lbl_Designation.AutoSize = true;
            this.lbl_Designation.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Designation.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Designation.Location = new System.Drawing.Point(172, 774);
            this.lbl_Designation.Name = "lbl_Designation";
            this.lbl_Designation.Size = new System.Drawing.Size(155, 34);
            this.lbl_Designation.TabIndex = 145;
            this.lbl_Designation.Text = "Designation";
            // 
            // tb_Salary
            // 
            this.tb_Salary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Salary.Location = new System.Drawing.Point(1308, 613);
            this.tb_Salary.Name = "tb_Salary";
            this.tb_Salary.Size = new System.Drawing.Size(346, 41);
            this.tb_Salary.TabIndex = 141;
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Salary.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary.Location = new System.Drawing.Point(1047, 620);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(89, 34);
            this.lbl_Salary.TabIndex = 146;
            this.lbl_Salary.Text = "Salary";
            // 
            // frm_Search_Or_Update_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.ControlBox = false;
            this.Controls.Add(this.tb_Note);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.tb_Designation);
            this.Controls.Add(this.lbl_Designation);
            this.Controls.Add(this.tb_Salary);
            this.Controls.Add(this.lbl_Salary);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.dtp_Joining_Date);
            this.Controls.Add(this.tb_Aadhaar_Card_No);
            this.Controls.Add(this.tb_Mobile_No_2);
            this.Controls.Add(this.tb_Mobile_No_1);
            this.Controls.Add(this.tb_Employee_Name);
            this.Controls.Add(this.lbl_Aadhaar_Card_No);
            this.Controls.Add(this.lbl_Mobile_No_2);
            this.Controls.Add(this.lbl_Mobile_No_1);
            this.Controls.Add(this.lbl_Joining_Date);
            this.Controls.Add(this.lbl_Employee_Name);
            this.Controls.Add(this.pnl_Search_Or_Update_Employee);
            this.Controls.Add(this.lbl_Search_Or_Update_Employee);
            this.Name = "frm_Search_Or_Update_Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Or Update Employee";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnl_Search_Or_Update_Employee.ResumeLayout(false);
            this.pnl_Search_Or_Update_Employee.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.DateTimePicker dtp_Joining_Date;
        private System.Windows.Forms.TextBox tb_Aadhaar_Card_No;
        private System.Windows.Forms.TextBox tb_Mobile_No_2;
        private System.Windows.Forms.TextBox tb_Mobile_No_1;
        private System.Windows.Forms.TextBox tb_Employee_Name;
        private System.Windows.Forms.Label lbl_Aadhaar_Card_No;
        private System.Windows.Forms.Label lbl_Mobile_No_2;
        private System.Windows.Forms.Label lbl_Mobile_No_1;
        private System.Windows.Forms.Label lbl_Registration_N0;
        private System.Windows.Forms.Label lbl_Joining_Date;
        private System.Windows.Forms.Label lbl_Employee_Name;
        private System.Windows.Forms.Panel pnl_Search_Or_Update_Employee;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.TextBox tb_Employee_ID;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.Label lbl_Employee_ID;
        private System.Windows.Forms.Label lbl_Search_Or_Update_Employee;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.TextBox tb_Note;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.TextBox tb_Designation;
        private System.Windows.Forms.Label lbl_Designation;
        private System.Windows.Forms.TextBox tb_Salary;
        private System.Windows.Forms.Label lbl_Salary;
    }
}