﻿namespace Ganesh_Cycle_Agency
{
    partial class frm_Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Reports));
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.btn_Customer_Report_Datewise = new System.Windows.Forms.Button();
            this.btn_Product_Reports = new System.Windows.Forms.Button();
            this.btn_Stock = new System.Windows.Forms.Button();
            this.btn_Distributor_Reports = new System.Windows.Forms.Button();
            this.btn_Customer_Report_Namewise = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.Color.Black;
            this.btn_Back.Image = ((System.Drawing.Image)(resources.GetObject("btn_Back.Image")));
            this.btn_Back.Location = new System.Drawing.Point(97, 48);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(67, 55);
            this.btn_Back.TabIndex = 19;
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Logout
            // 
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.ForeColor = System.Drawing.Color.Black;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.Location = new System.Drawing.Point(1758, 48);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(75, 55);
            this.btn_Logout.TabIndex = 18;
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // btn_Customer_Report_Datewise
            // 
            this.btn_Customer_Report_Datewise.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Customer_Report_Datewise.Location = new System.Drawing.Point(673, 214);
            this.btn_Customer_Report_Datewise.Name = "btn_Customer_Report_Datewise";
            this.btn_Customer_Report_Datewise.Size = new System.Drawing.Size(569, 81);
            this.btn_Customer_Report_Datewise.TabIndex = 16;
            this.btn_Customer_Report_Datewise.Text = "Customer Report Datewise";
            this.btn_Customer_Report_Datewise.UseVisualStyleBackColor = true;
            this.btn_Customer_Report_Datewise.Click += new System.EventHandler(this.btn_Customer_Report_Click);
            // 
            // btn_Product_Reports
            // 
            this.btn_Product_Reports.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Product_Reports.Location = new System.Drawing.Point(673, 525);
            this.btn_Product_Reports.Name = "btn_Product_Reports";
            this.btn_Product_Reports.Size = new System.Drawing.Size(569, 81);
            this.btn_Product_Reports.TabIndex = 17;
            this.btn_Product_Reports.Text = "Product Reports";
            this.btn_Product_Reports.UseVisualStyleBackColor = true;
            this.btn_Product_Reports.Click += new System.EventHandler(this.btn_Product_Reports_Click);
            // 
            // btn_Stock
            // 
            this.btn_Stock.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Stock.Location = new System.Drawing.Point(673, 657);
            this.btn_Stock.Name = "btn_Stock";
            this.btn_Stock.Size = new System.Drawing.Size(569, 81);
            this.btn_Stock.TabIndex = 20;
            this.btn_Stock.Text = "Stock Reports";
            this.btn_Stock.UseVisualStyleBackColor = true;
            this.btn_Stock.Click += new System.EventHandler(this.btn_Stock_Click);
            // 
            // btn_Distributor_Reports
            // 
            this.btn_Distributor_Reports.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Distributor_Reports.Location = new System.Drawing.Point(673, 797);
            this.btn_Distributor_Reports.Name = "btn_Distributor_Reports";
            this.btn_Distributor_Reports.Size = new System.Drawing.Size(569, 81);
            this.btn_Distributor_Reports.TabIndex = 21;
            this.btn_Distributor_Reports.Text = "Distributor Reports";
            this.btn_Distributor_Reports.UseVisualStyleBackColor = true;
            this.btn_Distributor_Reports.Click += new System.EventHandler(this.btn_Distributor_Reports_Click);
            // 
            // btn_Customer_Report_Namewise
            // 
            this.btn_Customer_Report_Namewise.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Customer_Report_Namewise.Location = new System.Drawing.Point(673, 379);
            this.btn_Customer_Report_Namewise.Name = "btn_Customer_Report_Namewise";
            this.btn_Customer_Report_Namewise.Size = new System.Drawing.Size(569, 81);
            this.btn_Customer_Report_Namewise.TabIndex = 22;
            this.btn_Customer_Report_Namewise.Text = "Customer Report Namewise";
            this.btn_Customer_Report_Namewise.UseVisualStyleBackColor = true;
            this.btn_Customer_Report_Namewise.Click += new System.EventHandler(this.btn_Customer_Report_Namewise_Click);
            // 
            // frm_Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Customer_Report_Namewise);
            this.Controls.Add(this.btn_Distributor_Reports);
            this.Controls.Add(this.btn_Stock);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.btn_Customer_Report_Datewise);
            this.Controls.Add(this.btn_Product_Reports);
            this.Name = "frm_Reports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reports";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Button btn_Customer_Report_Datewise;
        private System.Windows.Forms.Button btn_Product_Reports;
        private System.Windows.Forms.Button btn_Stock;
        private System.Windows.Forms.Button btn_Distributor_Reports;
        private System.Windows.Forms.Button btn_Customer_Report_Namewise;
    }
}