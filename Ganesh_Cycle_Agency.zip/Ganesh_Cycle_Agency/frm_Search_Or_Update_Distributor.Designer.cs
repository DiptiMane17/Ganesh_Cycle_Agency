﻿namespace Ganesh_Cycle_Agency
{
    partial class frm_Search_Or_Update_Distributor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Search_Or_Update_Distributor));
            this.pnl_Search_Or_Update = new System.Windows.Forms.Panel();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.tb_Distributor_ID = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.lbl_Distributor_ID = new System.Windows.Forms.Label();
            this.lbl_Search_Or_Update_Distributor = new System.Windows.Forms.Label();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.tb_Mobile_No_2 = new System.Windows.Forms.TextBox();
            this.tb_Note = new System.Windows.Forms.TextBox();
            this.lbl_Distributor_Name = new System.Windows.Forms.Label();
            this.tb_Brand = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No_1 = new System.Windows.Forms.Label();
            this.tb_PAN_Card = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No_2 = new System.Windows.Forms.Label();
            this.tb_Aadhar_Card_No = new System.Windows.Forms.TextBox();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.lbl_Brand = new System.Windows.Forms.Label();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.tb_Mobile_No_1 = new System.Windows.Forms.TextBox();
            this.lbl_PAN_Card = new System.Windows.Forms.Label();
            this.tb_Distributor_Name = new System.Windows.Forms.TextBox();
            this.lbl_Aadhaar_Card_No = new System.Windows.Forms.Label();
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.pnl_Search_Or_Update.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Search_Or_Update
            // 
            this.pnl_Search_Or_Update.BackColor = System.Drawing.Color.Silver;
            this.pnl_Search_Or_Update.Controls.Add(this.btn_Refresh);
            this.pnl_Search_Or_Update.Controls.Add(this.btn_Update);
            this.pnl_Search_Or_Update.Controls.Add(this.tb_Distributor_ID);
            this.pnl_Search_Or_Update.Controls.Add(this.btn_Search);
            this.pnl_Search_Or_Update.Controls.Add(this.lbl_Distributor_ID);
            this.pnl_Search_Or_Update.Location = new System.Drawing.Point(118, 153);
            this.pnl_Search_Or_Update.Name = "pnl_Search_Or_Update";
            this.pnl_Search_Or_Update.Size = new System.Drawing.Size(1649, 78);
            this.pnl_Search_Or_Update.TabIndex = 69;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 22.2F);
            this.btn_Refresh.Location = new System.Drawing.Point(1381, 13);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(161, 50);
            this.btn_Refresh.TabIndex = 4;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Update.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.Location = new System.Drawing.Point(1101, 12);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(181, 53);
            this.btn_Update.TabIndex = 3;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // tb_Distributor_ID
            // 
            this.tb_Distributor_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Distributor_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_ID.Location = new System.Drawing.Point(328, 22);
            this.tb_Distributor_ID.Name = "tb_Distributor_ID";
            this.tb_Distributor_ID.Size = new System.Drawing.Size(302, 42);
            this.tb_Distributor_ID.TabIndex = 1;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.SystemColors.Control;
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(800, 13);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(181, 53);
            this.btn_Search.TabIndex = 2;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // lbl_Distributor_ID
            // 
            this.lbl_Distributor_ID.AutoSize = true;
            this.lbl_Distributor_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_ID.Location = new System.Drawing.Point(38, 24);
            this.lbl_Distributor_ID.Name = "lbl_Distributor_ID";
            this.lbl_Distributor_ID.Size = new System.Drawing.Size(182, 34);
            this.lbl_Distributor_ID.TabIndex = 47;
            this.lbl_Distributor_ID.Text = "Distributor ID";
            // 
            // lbl_Search_Or_Update_Distributor
            // 
            this.lbl_Search_Or_Update_Distributor.AutoSize = true;
            this.lbl_Search_Or_Update_Distributor.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Search_Or_Update_Distributor.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Search_Or_Update_Distributor.Location = new System.Drawing.Point(535, 45);
            this.lbl_Search_Or_Update_Distributor.Name = "lbl_Search_Or_Update_Distributor";
            this.lbl_Search_Or_Update_Distributor.Size = new System.Drawing.Size(833, 77);
            this.lbl_Search_Or_Update_Distributor.TabIndex = 68;
            this.lbl_Search_Or_Update_Distributor.Text = "Search Or Update Distributor";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Date.Location = new System.Drawing.Point(1394, 284);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(319, 39);
            this.dtp_Date.TabIndex = 126;
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(1124, 289);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(162, 34);
            this.lbl_Tie_Up_Date.TabIndex = 125;
            this.lbl_Tie_Up_Date.Text = "Tie Up Date";
            // 
            // tb_Mobile_No_2
            // 
            this.tb_Mobile_No_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_2.Location = new System.Drawing.Point(457, 546);
            this.tb_Mobile_No_2.MaxLength = 10;
            this.tb_Mobile_No_2.Name = "tb_Mobile_No_2";
            this.tb_Mobile_No_2.Size = new System.Drawing.Size(302, 42);
            this.tb_Mobile_No_2.TabIndex = 115;
            // 
            // tb_Note
            // 
            this.tb_Note.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Note.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Note.Location = new System.Drawing.Point(1394, 696);
            this.tb_Note.MaxLength = 50;
            this.tb_Note.Multiline = true;
            this.tb_Note.Name = "tb_Note";
            this.tb_Note.Size = new System.Drawing.Size(319, 114);
            this.tb_Note.TabIndex = 120;
            // 
            // lbl_Distributor_Name
            // 
            this.lbl_Distributor_Name.AutoSize = true;
            this.lbl_Distributor_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Distributor_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_Name.Location = new System.Drawing.Point(167, 289);
            this.lbl_Distributor_Name.Name = "lbl_Distributor_Name";
            this.lbl_Distributor_Name.Size = new System.Drawing.Size(222, 34);
            this.lbl_Distributor_Name.TabIndex = 110;
            this.lbl_Distributor_Name.Text = "Distributor Name";
            // 
            // tb_Brand
            // 
            this.tb_Brand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Brand.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Brand.Location = new System.Drawing.Point(1394, 517);
            this.tb_Brand.Multiline = true;
            this.tb_Brand.Name = "tb_Brand";
            this.tb_Brand.Size = new System.Drawing.Size(319, 91);
            this.tb_Brand.TabIndex = 119;
            // 
            // lbl_Mobile_No_1
            // 
            this.lbl_Mobile_No_1.AutoSize = true;
            this.lbl_Mobile_No_1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_1.Location = new System.Drawing.Point(167, 419);
            this.lbl_Mobile_No_1.Name = "lbl_Mobile_No_1";
            this.lbl_Mobile_No_1.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_1.TabIndex = 111;
            this.lbl_Mobile_No_1.Text = "Mobile No 1";
            // 
            // tb_PAN_Card
            // 
            this.tb_PAN_Card.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_PAN_Card.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_PAN_Card.Location = new System.Drawing.Point(1394, 404);
            this.tb_PAN_Card.MaxLength = 10;
            this.tb_PAN_Card.Name = "tb_PAN_Card";
            this.tb_PAN_Card.Size = new System.Drawing.Size(319, 41);
            this.tb_PAN_Card.TabIndex = 118;
            // 
            // lbl_Mobile_No_2
            // 
            this.lbl_Mobile_No_2.AutoSize = true;
            this.lbl_Mobile_No_2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_2.Location = new System.Drawing.Point(167, 548);
            this.lbl_Mobile_No_2.Name = "lbl_Mobile_No_2";
            this.lbl_Mobile_No_2.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_2.TabIndex = 112;
            this.lbl_Mobile_No_2.Text = "Mobile No 2";
            // 
            // tb_Aadhar_Card_No
            // 
            this.tb_Aadhar_Card_No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Aadhar_Card_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_Card_No.Location = new System.Drawing.Point(457, 808);
            this.tb_Aadhar_Card_No.MaxLength = 12;
            this.tb_Aadhar_Card_No.Name = "tb_Aadhar_Card_No";
            this.tb_Aadhar_Card_No.Size = new System.Drawing.Size(302, 41);
            this.tb_Aadhar_Card_No.TabIndex = 117;
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email_ID.Location = new System.Drawing.Point(167, 668);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(122, 34);
            this.lbl_Email_ID.TabIndex = 107;
            this.lbl_Email_ID.Text = "Email ID";
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Email_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email_ID.Location = new System.Drawing.Point(457, 666);
            this.tb_Email_ID.MaxLength = 20;
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(302, 42);
            this.tb_Email_ID.TabIndex = 116;
            // 
            // lbl_Brand
            // 
            this.lbl_Brand.AutoSize = true;
            this.lbl_Brand.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Brand.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Brand.Location = new System.Drawing.Point(1124, 536);
            this.lbl_Brand.Name = "lbl_Brand";
            this.lbl_Brand.Size = new System.Drawing.Size(88, 34);
            this.lbl_Brand.TabIndex = 108;
            this.lbl_Brand.Text = "Brand";
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Note.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.Location = new System.Drawing.Point(1124, 737);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(73, 34);
            this.lbl_Note.TabIndex = 109;
            this.lbl_Note.Text = "Note";
            // 
            // tb_Mobile_No_1
            // 
            this.tb_Mobile_No_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_1.Location = new System.Drawing.Point(457, 417);
            this.tb_Mobile_No_1.MaxLength = 10;
            this.tb_Mobile_No_1.Name = "tb_Mobile_No_1";
            this.tb_Mobile_No_1.Size = new System.Drawing.Size(302, 42);
            this.tb_Mobile_No_1.TabIndex = 114;
            // 
            // lbl_PAN_Card
            // 
            this.lbl_PAN_Card.AutoSize = true;
            this.lbl_PAN_Card.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PAN_Card.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PAN_Card.Location = new System.Drawing.Point(1124, 402);
            this.lbl_PAN_Card.Name = "lbl_PAN_Card";
            this.lbl_PAN_Card.Size = new System.Drawing.Size(138, 34);
            this.lbl_PAN_Card.TabIndex = 122;
            this.lbl_PAN_Card.Text = "PAN Card";
            // 
            // tb_Distributor_Name
            // 
            this.tb_Distributor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Distributor_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_Name.Location = new System.Drawing.Point(457, 287);
            this.tb_Distributor_Name.MaxLength = 20;
            this.tb_Distributor_Name.Name = "tb_Distributor_Name";
            this.tb_Distributor_Name.Size = new System.Drawing.Size(302, 42);
            this.tb_Distributor_Name.TabIndex = 113;
            // 
            // lbl_Aadhaar_Card_No
            // 
            this.lbl_Aadhaar_Card_No.AutoSize = true;
            this.lbl_Aadhaar_Card_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aadhaar_Card_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhaar_Card_No.Location = new System.Drawing.Point(167, 808);
            this.lbl_Aadhaar_Card_No.Name = "lbl_Aadhaar_Card_No";
            this.lbl_Aadhaar_Card_No.Size = new System.Drawing.Size(226, 34);
            this.lbl_Aadhaar_Card_No.TabIndex = 123;
            this.lbl_Aadhaar_Card_No.Text = "Aadhaar Card No";
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.Color.Black;
            this.btn_Back.Image = ((System.Drawing.Image)(resources.GetObject("btn_Back.Image")));
            this.btn_Back.Location = new System.Drawing.Point(63, 21);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(67, 55);
            this.btn_Back.TabIndex = 128;
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Logout
            // 
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.ForeColor = System.Drawing.Color.Black;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.Location = new System.Drawing.Point(1745, 21);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(75, 55);
            this.btn_Logout.TabIndex = 127;
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // frm_Search_Or_Update_Distributor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.dtp_Date);
            this.Controls.Add(this.lbl_Tie_Up_Date);
            this.Controls.Add(this.tb_Mobile_No_2);
            this.Controls.Add(this.tb_Note);
            this.Controls.Add(this.lbl_Distributor_Name);
            this.Controls.Add(this.tb_Brand);
            this.Controls.Add(this.lbl_Mobile_No_1);
            this.Controls.Add(this.tb_PAN_Card);
            this.Controls.Add(this.lbl_Mobile_No_2);
            this.Controls.Add(this.tb_Aadhar_Card_No);
            this.Controls.Add(this.lbl_Email_ID);
            this.Controls.Add(this.tb_Email_ID);
            this.Controls.Add(this.lbl_Brand);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.tb_Mobile_No_1);
            this.Controls.Add(this.lbl_PAN_Card);
            this.Controls.Add(this.tb_Distributor_Name);
            this.Controls.Add(this.lbl_Aadhaar_Card_No);
            this.Controls.Add(this.pnl_Search_Or_Update);
            this.Controls.Add(this.lbl_Search_Or_Update_Distributor);
            this.Name = "frm_Search_Or_Update_Distributor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Or Update Distributor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnl_Search_Or_Update.ResumeLayout(false);
            this.pnl_Search_Or_Update.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Search_Or_Update;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.TextBox tb_Distributor_ID;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.Label lbl_Distributor_ID;
        private System.Windows.Forms.Label lbl_Search_Or_Update_Distributor;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.TextBox tb_Mobile_No_2;
        private System.Windows.Forms.TextBox tb_Note;
        private System.Windows.Forms.Label lbl_Distributor_Name;
        private System.Windows.Forms.TextBox tb_Brand;
        private System.Windows.Forms.Label lbl_Mobile_No_1;
        private System.Windows.Forms.TextBox tb_PAN_Card;
        private System.Windows.Forms.Label lbl_Mobile_No_2;
        private System.Windows.Forms.TextBox tb_Aadhar_Card_No;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.Label lbl_Brand;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.TextBox tb_Mobile_No_1;
        private System.Windows.Forms.Label lbl_PAN_Card;
        private System.Windows.Forms.TextBox tb_Distributor_Name;
        private System.Windows.Forms.Label lbl_Aadhaar_Card_No;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Logout;
    }
}