﻿namespace Ganesh_Cycle_Agency
{
    partial class frm_Add_New_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Employee));
            this.tb_Note = new System.Windows.Forms.TextBox();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.lbl_Add_New_Employee = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.dtp_Joining_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.tb_Designation = new System.Windows.Forms.TextBox();
            this.lbl_Designation = new System.Windows.Forms.Label();
            this.lbl_Employee_ID = new System.Windows.Forms.Label();
            this.tb_Salary = new System.Windows.Forms.TextBox();
            this.lbl_Employee_Name = new System.Windows.Forms.Label();
            this.lbl_Joining_Date = new System.Windows.Forms.Label();
            this.lbl_Registration_N0 = new System.Windows.Forms.Label();
            this.tb_Mobile_No_2 = new System.Windows.Forms.TextBox();
            this.lbl_Aadhaar_Card_No = new System.Windows.Forms.Label();
            this.tb_Mobile_No_1 = new System.Windows.Forms.TextBox();
            this.tb_Employee_ID = new System.Windows.Forms.TextBox();
            this.tb_Employee_Name = new System.Windows.Forms.TextBox();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.tb_Aadhar_Card_No = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No_1 = new System.Windows.Forms.Label();
            this.lbl_Mobile_No_2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_Note
            // 
            this.tb_Note.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Note.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Note.Location = new System.Drawing.Point(1380, 524);
            this.tb_Note.MaxLength = 50;
            this.tb_Note.Multiline = true;
            this.tb_Note.Name = "tb_Note";
            this.tb_Note.Size = new System.Drawing.Size(346, 120);
            this.tb_Note.TabIndex = 9;
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Note.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.Location = new System.Drawing.Point(1137, 586);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(73, 34);
            this.lbl_Note.TabIndex = 139;
            this.lbl_Note.Text = "Note";
            // 
            // btn_Logout
            // 
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.ForeColor = System.Drawing.Color.Black;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.Location = new System.Drawing.Point(1772, 34);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(68, 59);
            this.btn_Logout.TabIndex = 13;
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // lbl_Add_New_Employee
            // 
            this.lbl_Add_New_Employee.AutoSize = true;
            this.lbl_Add_New_Employee.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Add_New_Employee.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Add_New_Employee.ForeColor = System.Drawing.Color.Black;
            this.lbl_Add_New_Employee.Location = new System.Drawing.Point(630, 59);
            this.lbl_Add_New_Employee.Name = "lbl_Add_New_Employee";
            this.lbl_Add_New_Employee.Size = new System.Drawing.Size(580, 77);
            this.lbl_Add_New_Employee.TabIndex = 134;
            this.lbl_Add_New_Employee.Text = "Add New Employee";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.Silver;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(1332, 775);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(226, 70);
            this.btn_Refresh.TabIndex = 11;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // dtp_Joining_Date
            // 
            this.dtp_Joining_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Joining_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Joining_Date.Location = new System.Drawing.Point(1381, 214);
            this.dtp_Joining_Date.Name = "dtp_Joining_Date";
            this.dtp_Joining_Date.Size = new System.Drawing.Size(346, 34);
            this.dtp_Joining_Date.TabIndex = 6;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.Silver;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(522, 775);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(226, 70);
            this.btn_Save.TabIndex = 10;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Image = ((System.Drawing.Image)(resources.GetObject("btn_Back.Image")));
            this.btn_Back.Location = new System.Drawing.Point(63, 48);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(63, 59);
            this.btn_Back.TabIndex = 12;
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // tb_Designation
            // 
            this.tb_Designation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Designation.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Designation.Location = new System.Drawing.Point(508, 632);
            this.tb_Designation.Name = "tb_Designation";
            this.tb_Designation.Size = new System.Drawing.Size(346, 42);
            this.tb_Designation.TabIndex = 5;
            this.tb_Designation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_TextDigit);
            // 
            // lbl_Designation
            // 
            this.lbl_Designation.AutoSize = true;
            this.lbl_Designation.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Designation.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Designation.Location = new System.Drawing.Point(226, 642);
            this.lbl_Designation.Name = "lbl_Designation";
            this.lbl_Designation.Size = new System.Drawing.Size(155, 34);
            this.lbl_Designation.TabIndex = 126;
            this.lbl_Designation.Text = "Designation";
            // 
            // lbl_Employee_ID
            // 
            this.lbl_Employee_ID.AutoSize = true;
            this.lbl_Employee_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Employee_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_ID.Location = new System.Drawing.Point(226, 214);
            this.lbl_Employee_ID.Name = "lbl_Employee_ID";
            this.lbl_Employee_ID.Size = new System.Drawing.Size(172, 34);
            this.lbl_Employee_ID.TabIndex = 130;
            this.lbl_Employee_ID.Text = "Employee ID";
            // 
            // tb_Salary
            // 
            this.tb_Salary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Salary.Location = new System.Drawing.Point(1381, 418);
            this.tb_Salary.Name = "tb_Salary";
            this.tb_Salary.Size = new System.Drawing.Size(346, 41);
            this.tb_Salary.TabIndex = 8;
            this.tb_Salary.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Employee_Name
            // 
            this.lbl_Employee_Name.AutoSize = true;
            this.lbl_Employee_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Employee_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_Name.Location = new System.Drawing.Point(226, 303);
            this.lbl_Employee_Name.Name = "lbl_Employee_Name";
            this.lbl_Employee_Name.Size = new System.Drawing.Size(212, 34);
            this.lbl_Employee_Name.TabIndex = 129;
            this.lbl_Employee_Name.Text = "Employee Name";
            // 
            // lbl_Joining_Date
            // 
            this.lbl_Joining_Date.AutoSize = true;
            this.lbl_Joining_Date.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Joining_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Joining_Date.Location = new System.Drawing.Point(1137, 213);
            this.lbl_Joining_Date.Name = "lbl_Joining_Date";
            this.lbl_Joining_Date.Size = new System.Drawing.Size(164, 34);
            this.lbl_Joining_Date.TabIndex = 128;
            this.lbl_Joining_Date.Text = "Joining Date";
            // 
            // lbl_Registration_N0
            // 
            this.lbl_Registration_N0.AutoSize = true;
            this.lbl_Registration_N0.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Registration_N0.Location = new System.Drawing.Point(474, 59);
            this.lbl_Registration_N0.Name = "lbl_Registration_N0";
            this.lbl_Registration_N0.Size = new System.Drawing.Size(0, 34);
            this.lbl_Registration_N0.TabIndex = 125;
            // 
            // tb_Mobile_No_2
            // 
            this.tb_Mobile_No_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_2.Location = new System.Drawing.Point(512, 521);
            this.tb_Mobile_No_2.MaxLength = 10;
            this.tb_Mobile_No_2.Name = "tb_Mobile_No_2";
            this.tb_Mobile_No_2.Size = new System.Drawing.Size(342, 42);
            this.tb_Mobile_No_2.TabIndex = 4;
            this.tb_Mobile_No_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Aadhaar_Card_No
            // 
            this.lbl_Aadhaar_Card_No.AutoSize = true;
            this.lbl_Aadhaar_Card_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aadhaar_Card_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhaar_Card_No.Location = new System.Drawing.Point(1137, 319);
            this.lbl_Aadhaar_Card_No.Name = "lbl_Aadhaar_Card_No";
            this.lbl_Aadhaar_Card_No.Size = new System.Drawing.Size(226, 34);
            this.lbl_Aadhaar_Card_No.TabIndex = 135;
            this.lbl_Aadhaar_Card_No.Text = "Aadhaar Card No";
            // 
            // tb_Mobile_No_1
            // 
            this.tb_Mobile_No_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_1.Location = new System.Drawing.Point(512, 419);
            this.tb_Mobile_No_1.MaxLength = 10;
            this.tb_Mobile_No_1.Name = "tb_Mobile_No_1";
            this.tb_Mobile_No_1.Size = new System.Drawing.Size(342, 42);
            this.tb_Mobile_No_1.TabIndex = 3;
            this.tb_Mobile_No_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Employee_ID
            // 
            this.tb_Employee_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Employee_ID.Enabled = false;
            this.tb_Employee_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employee_ID.Location = new System.Drawing.Point(508, 214);
            this.tb_Employee_ID.MaxLength = 10;
            this.tb_Employee_ID.Name = "tb_Employee_ID";
            this.tb_Employee_ID.Size = new System.Drawing.Size(342, 42);
            this.tb_Employee_ID.TabIndex = 1;
            // 
            // tb_Employee_Name
            // 
            this.tb_Employee_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Employee_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employee_Name.Location = new System.Drawing.Point(508, 319);
            this.tb_Employee_Name.MaxLength = 20;
            this.tb_Employee_Name.Name = "tb_Employee_Name";
            this.tb_Employee_Name.Size = new System.Drawing.Size(342, 42);
            this.tb_Employee_Name.TabIndex = 2;
            this.tb_Employee_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Salary.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary.Location = new System.Drawing.Point(1137, 413);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(89, 34);
            this.lbl_Salary.TabIndex = 127;
            this.lbl_Salary.Text = "Salary";
            // 
            // tb_Aadhar_Card_No
            // 
            this.tb_Aadhar_Card_No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Aadhar_Card_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_Card_No.Location = new System.Drawing.Point(1381, 319);
            this.tb_Aadhar_Card_No.MaxLength = 12;
            this.tb_Aadhar_Card_No.Name = "tb_Aadhar_Card_No";
            this.tb_Aadhar_Card_No.Size = new System.Drawing.Size(346, 41);
            this.tb_Aadhar_Card_No.TabIndex = 7;
            this.tb_Aadhar_Card_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No_1
            // 
            this.lbl_Mobile_No_1.AutoSize = true;
            this.lbl_Mobile_No_1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_1.Location = new System.Drawing.Point(226, 427);
            this.lbl_Mobile_No_1.Name = "lbl_Mobile_No_1";
            this.lbl_Mobile_No_1.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_1.TabIndex = 132;
            this.lbl_Mobile_No_1.Text = "Mobile No 1";
            // 
            // lbl_Mobile_No_2
            // 
            this.lbl_Mobile_No_2.AutoSize = true;
            this.lbl_Mobile_No_2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_2.Location = new System.Drawing.Point(226, 529);
            this.lbl_Mobile_No_2.Name = "lbl_Mobile_No_2";
            this.lbl_Mobile_No_2.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_2.TabIndex = 131;
            this.lbl_Mobile_No_2.Text = "Mobile No 2";
            // 
            // frm_Add_New_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.ControlBox = false;
            this.Controls.Add(this.tb_Note);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.lbl_Add_New_Employee);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.dtp_Joining_Date);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.tb_Designation);
            this.Controls.Add(this.lbl_Designation);
            this.Controls.Add(this.lbl_Employee_ID);
            this.Controls.Add(this.tb_Salary);
            this.Controls.Add(this.lbl_Employee_Name);
            this.Controls.Add(this.lbl_Joining_Date);
            this.Controls.Add(this.lbl_Registration_N0);
            this.Controls.Add(this.tb_Mobile_No_2);
            this.Controls.Add(this.lbl_Aadhaar_Card_No);
            this.Controls.Add(this.tb_Mobile_No_1);
            this.Controls.Add(this.tb_Employee_ID);
            this.Controls.Add(this.tb_Employee_Name);
            this.Controls.Add(this.lbl_Salary);
            this.Controls.Add(this.tb_Aadhar_Card_No);
            this.Controls.Add(this.lbl_Mobile_No_1);
            this.Controls.Add(this.lbl_Mobile_No_2);
            this.Name = "frm_Add_New_Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Employee";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Add_New_Employee_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Note;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Label lbl_Add_New_Employee;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.DateTimePicker dtp_Joining_Date;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.TextBox tb_Designation;
        private System.Windows.Forms.Label lbl_Designation;
        private System.Windows.Forms.Label lbl_Employee_ID;
        private System.Windows.Forms.TextBox tb_Salary;
        private System.Windows.Forms.Label lbl_Employee_Name;
        private System.Windows.Forms.Label lbl_Joining_Date;
        private System.Windows.Forms.Label lbl_Registration_N0;
        private System.Windows.Forms.TextBox tb_Mobile_No_2;
        private System.Windows.Forms.Label lbl_Aadhaar_Card_No;
        private System.Windows.Forms.TextBox tb_Mobile_No_1;
        private System.Windows.Forms.TextBox tb_Employee_ID;
        private System.Windows.Forms.TextBox tb_Employee_Name;
        private System.Windows.Forms.Label lbl_Salary;
        private System.Windows.Forms.TextBox tb_Aadhar_Card_No;
        private System.Windows.Forms.Label lbl_Mobile_No_1;
        private System.Windows.Forms.Label lbl_Mobile_No_2;
    }
}