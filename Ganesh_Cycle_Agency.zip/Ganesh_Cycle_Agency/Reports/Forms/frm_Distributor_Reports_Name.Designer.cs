﻿namespace Ganesh_Cycle_Agency.Reports.Forms
{
    partial class frm_Distributor_Reports_Name
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Distributor_Reports_Name));
            this.lbl_Ganesh_Cycle_Agency = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.tb_Distributor_Name = new System.Windows.Forms.TextBox();
            this.lbl_Distributor_Name = new System.Windows.Forms.Label();
            this.crv_Distributor_Reports = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Ganesh_Cycle_Agency
            // 
            this.lbl_Ganesh_Cycle_Agency.AutoSize = true;
            this.lbl_Ganesh_Cycle_Agency.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ganesh_Cycle_Agency.Location = new System.Drawing.Point(763, 28);
            this.lbl_Ganesh_Cycle_Agency.Name = "lbl_Ganesh_Cycle_Agency";
            this.lbl_Ganesh_Cycle_Agency.Size = new System.Drawing.Size(557, 68);
            this.lbl_Ganesh_Cycle_Agency.TabIndex = 10;
            this.lbl_Ganesh_Cycle_Agency.Text = "Ganesh Cycle Agency";
            // 
            // btn_Search
            // 
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(995, 151);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(176, 52);
            this.btn_Search.TabIndex = 9;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // tb_Distributor_Name
            // 
            this.tb_Distributor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Distributor_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_Name.Location = new System.Drawing.Point(443, 161);
            this.tb_Distributor_Name.Name = "tb_Distributor_Name";
            this.tb_Distributor_Name.Size = new System.Drawing.Size(275, 34);
            this.tb_Distributor_Name.TabIndex = 8;
            // 
            // lbl_Distributor_Name
            // 
            this.lbl_Distributor_Name.AutoSize = true;
            this.lbl_Distributor_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_Name.Location = new System.Drawing.Point(107, 151);
            this.lbl_Distributor_Name.Name = "lbl_Distributor_Name";
            this.lbl_Distributor_Name.Size = new System.Drawing.Size(209, 33);
            this.lbl_Distributor_Name.TabIndex = 7;
            this.lbl_Distributor_Name.Text = "Distributor Name";
            // 
            // crv_Distributor_Reports
            // 
            this.crv_Distributor_Reports.ActiveViewIndex = -1;
            this.crv_Distributor_Reports.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crv_Distributor_Reports.Cursor = System.Windows.Forms.Cursors.Default;
            this.crv_Distributor_Reports.Location = new System.Drawing.Point(13, 261);
            this.crv_Distributor_Reports.Name = "crv_Distributor_Reports";
            this.crv_Distributor_Reports.Size = new System.Drawing.Size(1844, 680);
            this.crv_Distributor_Reports.TabIndex = 11;
            this.crv_Distributor_Reports.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.Color.Black;
            this.btn_Back.Image = ((System.Drawing.Image)(resources.GetObject("btn_Back.Image")));
            this.btn_Back.Location = new System.Drawing.Point(50, 28);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(67, 55);
            this.btn_Back.TabIndex = 21;
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Logout
            // 
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.ForeColor = System.Drawing.Color.Black;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.Location = new System.Drawing.Point(1711, 28);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(75, 55);
            this.btn_Logout.TabIndex = 20;
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // frm_Distributor_Reports_Name
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.crv_Distributor_Reports);
            this.Controls.Add(this.lbl_Ganesh_Cycle_Agency);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.tb_Distributor_Name);
            this.Controls.Add(this.lbl_Distributor_Name);
            this.Name = "frm_Distributor_Reports_Name";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Distributor Reports Name";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Distributor_Reports_Name_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Ganesh_Cycle_Agency;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox tb_Distributor_Name;
        private System.Windows.Forms.Label lbl_Distributor_Name;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crv_Distributor_Reports;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Logout;
    }
}