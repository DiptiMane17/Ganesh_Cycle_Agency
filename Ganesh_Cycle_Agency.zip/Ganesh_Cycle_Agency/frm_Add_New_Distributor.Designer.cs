﻿namespace Ganesh_Cycle_Agency
{
    partial class frm_Add_New_Distributor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Distributor));
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Note = new System.Windows.Forms.TextBox();
            this.tb_Brand = new System.Windows.Forms.TextBox();
            this.tb_PAN_Card = new System.Windows.Forms.TextBox();
            this.tb_Aadhar_Card_No = new System.Windows.Forms.TextBox();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No_2 = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No_1 = new System.Windows.Forms.TextBox();
            this.tb_Distributor_Name = new System.Windows.Forms.TextBox();
            this.tb_Distributor_ID = new System.Windows.Forms.TextBox();
            this.lbl_Aadhaar_Card_No = new System.Windows.Forms.Label();
            this.lbl_PAN_Card = new System.Windows.Forms.Label();
            this.lbl_Add_New_Distributor = new System.Windows.Forms.Label();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.lbl_Brand = new System.Windows.Forms.Label();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.lbl_Registration_N0 = new System.Windows.Forms.Label();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.lbl_Mobile_No_2 = new System.Windows.Forms.Label();
            this.lbl_Mobile_No_1 = new System.Windows.Forms.Label();
            this.lbl_Distributor_Name = new System.Windows.Forms.Label();
            this.lbl_Distributor_ID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Image = ((System.Drawing.Image)(resources.GetObject("btn_Back.Image")));
            this.btn_Back.Location = new System.Drawing.Point(77, 26);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(69, 62);
            this.btn_Back.TabIndex = 13;
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Logout
            // 
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.ForeColor = System.Drawing.Color.Black;
            this.btn_Logout.Image = ((System.Drawing.Image)(resources.GetObject("btn_Logout.Image")));
            this.btn_Logout.Location = new System.Drawing.Point(1772, 26);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(74, 62);
            this.btn_Logout.TabIndex = 14;
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.DarkGray;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(1147, 821);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(226, 70);
            this.btn_Refresh.TabIndex = 12;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.DarkGray;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(512, 821);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(226, 70);
            this.btn_Save.TabIndex = 11;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Date.Location = new System.Drawing.Point(1334, 209);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(319, 39);
            this.dtp_Date.TabIndex = 1097;
            // 
            // tb_Note
            // 
            this.tb_Note.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Note.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Note.Location = new System.Drawing.Point(1334, 568);
            this.tb_Note.MaxLength = 50;
            this.tb_Note.Multiline = true;
            this.tb_Note.Name = "tb_Note";
            this.tb_Note.Size = new System.Drawing.Size(319, 111);
            this.tb_Note.TabIndex = 10;
            // 
            // tb_Brand
            // 
            this.tb_Brand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Brand.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Brand.Location = new System.Drawing.Point(1334, 385);
            this.tb_Brand.Multiline = true;
            this.tb_Brand.Name = "tb_Brand";
            this.tb_Brand.Size = new System.Drawing.Size(319, 91);
            this.tb_Brand.TabIndex = 9;
            // 
            // tb_PAN_Card
            // 
            this.tb_PAN_Card.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_PAN_Card.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_PAN_Card.Location = new System.Drawing.Point(1334, 296);
            this.tb_PAN_Card.MaxLength = 10;
            this.tb_PAN_Card.Name = "tb_PAN_Card";
            this.tb_PAN_Card.Size = new System.Drawing.Size(319, 41);
            this.tb_PAN_Card.TabIndex = 8;
            this.tb_PAN_Card.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_TextDigit);
            // 
            // tb_Aadhar_Card_No
            // 
            this.tb_Aadhar_Card_No.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Aadhar_Card_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_Card_No.Location = new System.Drawing.Point(539, 668);
            this.tb_Aadhar_Card_No.MaxLength = 12;
            this.tb_Aadhar_Card_No.Name = "tb_Aadhar_Card_No";
            this.tb_Aadhar_Card_No.Size = new System.Drawing.Size(302, 41);
            this.tb_Aadhar_Card_No.TabIndex = 6;
            this.tb_Aadhar_Card_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Email_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email_ID.Location = new System.Drawing.Point(539, 578);
            this.tb_Email_ID.MaxLength = 20;
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(302, 42);
            this.tb_Email_ID.TabIndex = 5;
            this.tb_Email_ID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_TextDigit);
            // 
            // tb_Mobile_No_2
            // 
            this.tb_Mobile_No_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_2.Location = new System.Drawing.Point(539, 485);
            this.tb_Mobile_No_2.MaxLength = 10;
            this.tb_Mobile_No_2.Name = "tb_Mobile_No_2";
            this.tb_Mobile_No_2.Size = new System.Drawing.Size(302, 42);
            this.tb_Mobile_No_2.TabIndex = 4;
            this.tb_Mobile_No_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Mobile_No_1
            // 
            this.tb_Mobile_No_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No_1.Location = new System.Drawing.Point(539, 388);
            this.tb_Mobile_No_1.MaxLength = 10;
            this.tb_Mobile_No_1.Name = "tb_Mobile_No_1";
            this.tb_Mobile_No_1.Size = new System.Drawing.Size(302, 42);
            this.tb_Mobile_No_1.TabIndex = 3;
            this.tb_Mobile_No_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Distributor_Name
            // 
            this.tb_Distributor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Distributor_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_Name.Location = new System.Drawing.Point(539, 300);
            this.tb_Distributor_Name.MaxLength = 20;
            this.tb_Distributor_Name.Name = "tb_Distributor_Name";
            this.tb_Distributor_Name.Size = new System.Drawing.Size(302, 42);
            this.tb_Distributor_Name.TabIndex = 2;
            this.tb_Distributor_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Distributor_ID
            // 
            this.tb_Distributor_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Distributor_ID.Enabled = false;
            this.tb_Distributor_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_ID.Location = new System.Drawing.Point(539, 212);
            this.tb_Distributor_ID.MaxLength = 10;
            this.tb_Distributor_ID.Name = "tb_Distributor_ID";
            this.tb_Distributor_ID.Size = new System.Drawing.Size(302, 42);
            this.tb_Distributor_ID.TabIndex = 1;
            // 
            // lbl_Aadhaar_Card_No
            // 
            this.lbl_Aadhaar_Card_No.AutoSize = true;
            this.lbl_Aadhaar_Card_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Aadhaar_Card_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhaar_Card_No.Location = new System.Drawing.Point(249, 668);
            this.lbl_Aadhaar_Card_No.Name = "lbl_Aadhaar_Card_No";
            this.lbl_Aadhaar_Card_No.Size = new System.Drawing.Size(226, 34);
            this.lbl_Aadhaar_Card_No.TabIndex = 119;
            this.lbl_Aadhaar_Card_No.Text = "Aadhaar Card No";
            // 
            // lbl_PAN_Card
            // 
            this.lbl_PAN_Card.AutoSize = true;
            this.lbl_PAN_Card.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PAN_Card.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PAN_Card.Location = new System.Drawing.Point(1064, 294);
            this.lbl_PAN_Card.Name = "lbl_PAN_Card";
            this.lbl_PAN_Card.Size = new System.Drawing.Size(138, 34);
            this.lbl_PAN_Card.TabIndex = 118;
            this.lbl_PAN_Card.Text = "PAN Card";
            // 
            // lbl_Add_New_Distributor
            // 
            this.lbl_Add_New_Distributor.AutoSize = true;
            this.lbl_Add_New_Distributor.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Add_New_Distributor.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Add_New_Distributor.Location = new System.Drawing.Point(704, 45);
            this.lbl_Add_New_Distributor.Name = "lbl_Add_New_Distributor";
            this.lbl_Add_New_Distributor.Size = new System.Drawing.Size(608, 77);
            this.lbl_Add_New_Distributor.TabIndex = 117;
            this.lbl_Add_New_Distributor.Text = "Add New Distributor";
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Note.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.Location = new System.Drawing.Point(1064, 606);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(73, 34);
            this.lbl_Note.TabIndex = 97;
            this.lbl_Note.Text = "Note";
            // 
            // lbl_Brand
            // 
            this.lbl_Brand.AutoSize = true;
            this.lbl_Brand.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Brand.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Brand.Location = new System.Drawing.Point(1064, 404);
            this.lbl_Brand.Name = "lbl_Brand";
            this.lbl_Brand.Size = new System.Drawing.Size(88, 34);
            this.lbl_Brand.TabIndex = 98;
            this.lbl_Brand.Text = "Brand";
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email_ID.Location = new System.Drawing.Point(249, 580);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(122, 34);
            this.lbl_Email_ID.TabIndex = 95;
            this.lbl_Email_ID.Text = "Email ID";
            // 
            // lbl_Registration_N0
            // 
            this.lbl_Registration_N0.AutoSize = true;
            this.lbl_Registration_N0.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Registration_N0.Location = new System.Drawing.Point(613, 243);
            this.lbl_Registration_N0.Name = "lbl_Registration_N0";
            this.lbl_Registration_N0.Size = new System.Drawing.Size(0, 34);
            this.lbl_Registration_N0.TabIndex = 96;
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(1064, 209);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(162, 34);
            this.lbl_Tie_Up_Date.TabIndex = 99;
            this.lbl_Tie_Up_Date.Text = "Tie Up Date";
            // 
            // lbl_Mobile_No_2
            // 
            this.lbl_Mobile_No_2.AutoSize = true;
            this.lbl_Mobile_No_2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_2.Location = new System.Drawing.Point(249, 487);
            this.lbl_Mobile_No_2.Name = "lbl_Mobile_No_2";
            this.lbl_Mobile_No_2.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_2.TabIndex = 102;
            this.lbl_Mobile_No_2.Text = "Mobile No 2";
            // 
            // lbl_Mobile_No_1
            // 
            this.lbl_Mobile_No_1.AutoSize = true;
            this.lbl_Mobile_No_1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No_1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No_1.Location = new System.Drawing.Point(249, 390);
            this.lbl_Mobile_No_1.Name = "lbl_Mobile_No_1";
            this.lbl_Mobile_No_1.Size = new System.Drawing.Size(167, 34);
            this.lbl_Mobile_No_1.TabIndex = 103;
            this.lbl_Mobile_No_1.Text = "Mobile No 1";
            // 
            // lbl_Distributor_Name
            // 
            this.lbl_Distributor_Name.AutoSize = true;
            this.lbl_Distributor_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Distributor_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_Name.Location = new System.Drawing.Point(249, 302);
            this.lbl_Distributor_Name.Name = "lbl_Distributor_Name";
            this.lbl_Distributor_Name.Size = new System.Drawing.Size(222, 34);
            this.lbl_Distributor_Name.TabIndex = 100;
            this.lbl_Distributor_Name.Text = "Distributor Name";
            // 
            // lbl_Distributor_ID
            // 
            this.lbl_Distributor_ID.AutoSize = true;
            this.lbl_Distributor_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Distributor_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_ID.Location = new System.Drawing.Point(249, 214);
            this.lbl_Distributor_ID.Name = "lbl_Distributor_ID";
            this.lbl_Distributor_ID.Size = new System.Drawing.Size(182, 34);
            this.lbl_Distributor_ID.TabIndex = 101;
            this.lbl_Distributor_ID.Text = "Distributor ID";
            // 
            // frm_Add_New_Distributor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1882, 953);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.dtp_Date);
            this.Controls.Add(this.tb_Note);
            this.Controls.Add(this.tb_Brand);
            this.Controls.Add(this.tb_PAN_Card);
            this.Controls.Add(this.tb_Aadhar_Card_No);
            this.Controls.Add(this.tb_Email_ID);
            this.Controls.Add(this.tb_Mobile_No_2);
            this.Controls.Add(this.tb_Mobile_No_1);
            this.Controls.Add(this.tb_Distributor_Name);
            this.Controls.Add(this.tb_Distributor_ID);
            this.Controls.Add(this.lbl_Aadhaar_Card_No);
            this.Controls.Add(this.lbl_PAN_Card);
            this.Controls.Add(this.lbl_Add_New_Distributor);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.lbl_Brand);
            this.Controls.Add(this.lbl_Email_ID);
            this.Controls.Add(this.lbl_Registration_N0);
            this.Controls.Add(this.lbl_Tie_Up_Date);
            this.Controls.Add(this.lbl_Mobile_No_2);
            this.Controls.Add(this.lbl_Mobile_No_1);
            this.Controls.Add(this.lbl_Distributor_Name);
            this.Controls.Add(this.lbl_Distributor_ID);
            this.Name = "frm_Add_New_Distributor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Customer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Add_New_Distributor_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Note;
        private System.Windows.Forms.TextBox tb_Brand;
        private System.Windows.Forms.TextBox tb_PAN_Card;
        private System.Windows.Forms.TextBox tb_Aadhar_Card_No;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.TextBox tb_Mobile_No_2;
        private System.Windows.Forms.TextBox tb_Mobile_No_1;
        private System.Windows.Forms.TextBox tb_Distributor_Name;
        private System.Windows.Forms.TextBox tb_Distributor_ID;
        private System.Windows.Forms.Label lbl_Aadhaar_Card_No;
        private System.Windows.Forms.Label lbl_PAN_Card;
        private System.Windows.Forms.Label lbl_Add_New_Distributor;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.Label lbl_Brand;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.Label lbl_Registration_N0;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.Label lbl_Mobile_No_2;
        private System.Windows.Forms.Label lbl_Mobile_No_1;
        private System.Windows.Forms.Label lbl_Distributor_Name;
        private System.Windows.Forms.Label lbl_Distributor_ID;
    }
}